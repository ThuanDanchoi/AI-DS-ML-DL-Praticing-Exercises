// Load the external data
Promise.all([
    d3.json('assets/json/map.json'), // Ensure this is the path to your TopoJSON file
    d3.csv('merged_df.csv') // Ensure this is the path to your CSV data
]).then(function([mapData, csvData]) {
    const svg = d3.select('#map').append('svg')
        .attr('width', '100%')
        .attr('height', '100%')
        .style('display', 'block');

    const width = document.getElementById('map').clientWidth;
    const height = document.getElementById('map').clientHeight;
    const projection = d3.geoMercator().fitSize([width, height], mapData);
    const path = d3.geoPath().projection(projection);

    // Tooltip setup
    const tooltip = d3.select('body').append('div')
        .attr('class', 'tooltip')
        .style('opacity', 0)
        .style('position', 'absolute')
        .style('padding', '10px')
        .style('background', 'rgba(0, 0, 0, 0.8)')
        .style('color', 'white')
        .style('pointer-events', 'none');

    // Process CSV data
    let dataByCountryYear = {};
    csvData.forEach(d => {
        const key = `${d.Country}-${d.Year}`;
        dataByCountryYear[key] = d; // Store whole data row
    });

    // Function to get color based on data type and value
    function getColor(value, type) {
        const scales = {
            'Calories': d3.scaleSequential(d3.interpolateReds).domain([0, 4000]),
            'Fat': d3.scaleSequential(d3.interpolateBlues).domain([0, 200]),
            'Protein': d3.scaleSequential(d3.interpolateGreens).domain([0, 100]),
            'Fruit': d3.scaleSequential(d3.interpolateOranges).domain([0, 500]),
            'Sugar': d3.scaleSequential(d3.interpolatePurples).domain([0, 300]),
            'Veg': d3.scaleSequential(d3.interpolateGreys).domain([0, 500]),
            'Obesity': d3.scaleSequential(d3.interpolateCool).domain([0, 40])
        };
        return scales[type](value);
    }

    // Update map function
    function updateMap() {
        const selectedYear = document.querySelector('input[name="year"]:checked').value;
        const selectedDataType = document.querySelector('input[name="data"]:checked').value;

        svg.selectAll('.country')
            .data(mapData.features)
            .join('path')
            .attr('class', 'country')
            .attr('d', path)
            .attr('fill', d => {
                const data = dataByCountryYear[`${d.properties.name}-${selectedYear}`];
                return data ? getColor(data[selectedDataType], selectedDataType) : '#ccc';
            })
            .attr('stroke', 'white')
            .on('mouseover', function(event, d) {
                svg.selectAll('.country').style('opacity', 0.2);
                d3.select(this).style('opacity', 1).classed('active', true);

                const key = `${d.properties.name}-${selectedYear}`;
                const data = dataByCountryYear[key];
                if (data) {
                    tooltip.style('opacity', 1)
                        .html(`Country: ${d.properties.name}<br>Year: ${data.Year}<br>${selectedDataType}: ${data[selectedDataType]}`)
                        .style('left', `${event.pageX + 20}px`)
                        .style('top', `${event.pageY + 20}px`);
                }
            })
            .on('mouseout', function() {
                svg.selectAll('.country').style('opacity', 1);
                d3.select(this).classed('active', false);
                tooltip.style('opacity', 0);
            });
    }

    // Display button event listener
    document.getElementById('display').addEventListener('click', updateMap);

    // Initialize map with default settings
    updateMap();
});
