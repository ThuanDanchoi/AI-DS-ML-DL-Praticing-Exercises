# Parallax Scrolling Website
## [Watch it on youtube](https://youtu.be/JrU6bsuNU7Y)
### Parallax Scrolling Website

- Parallax Scrolling Animation Using HTML CSS JAVASCRIPT
- Includes CSS animations.
- Includes parallax animation.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
